﻿# Define ADB path
$adbPath = "C:\AndroidSetup\platform-tools\adb.exe"

# Import CSV file (Ensure the CSV has 'IP' and 'Room' columns)
$devices = Import-Csv "C:\AndroidSetup\devices.csv"

foreach ($device in $devices) {
    # Clean 'Room' value: Strip spaces and non-visible characters
    $roomNumber = $device.Room -replace '^\s+|\s+$', ''  # Remove leading and trailing spaces
    $roomNumber = $roomNumber -replace '[^\x20-\x7E]', ''  # Remove non-ASCII characters

    # Ensure 'Room' value is not empty
    if (-not $roomNumber) {
        Write-Host "Warning: Room value is empty for device with IP $($device.IP). Skipping this device."
        continue  # Skip this device and move to the next one
    }

    # Remove any leading/trailing whitespace from 'IP'
    $deviceIP = $device.IP.Trim()

    Write-Host "Connecting to device at $deviceIP..."


    # Connect to the device
    & $adbPath connect $deviceIP
    Start-Sleep -Seconds 10   # Allow time to establish connection
      

    # Get the serial number
    $serialNumber = & $adbPath -s $deviceIP shell getprop ro.serialno
    $serialNumber = $serialNumber.Trim()

    if ([string]::IsNullOrWhiteSpace($serialNumber)) {
        Write-Host "Warning: Could not retrieve serial number for $deviceIP. Using 'UNKNOWN' instead."
        $serialNumber = "UNKNOWN"
    }

    # Concatenate Room number and Serial number for new device name
    $newDeviceName = "$roomNumber-$serialNumber"
    Write-Host "Renaming device to: $newDeviceName"

    # Rename the device
    & $adbPath -s $deviceIP shell settings put global device_name "$newDeviceName"
    Start-Sleep -Seconds 1

    Write-Host "Device renamed successfully!"

    # Remove Extra Apps
    $appsToRemove = @(
        "com.disney.disneyplus",
        "com.hulu.livingroomplus",
        "com.cbs.ott",
        "com.amazon.amazonvideo.livingroom",
        "com.google.android.youtube.tvunplugged"
        "com.google.android.youtube.tv",    
        "com.google.android.youtube.tvmusic"  
    )

    foreach ($app in $appsToRemove) {
        & $adbPath -s $deviceIP shell pm uninstall --user 0 $app
        Start-Sleep -Seconds 1
    }

        # Disable Vending App
    & $adbPath -s $deviceIP shell pm disable-user --user 0 com.android.vending
    Start-Sleep -Seconds 1
	
	
		#Enable Settings
	& $adbPath -s $deviceIP adb shell pm enable com.android.tv.settings
	Start-Sleep -Seconds 1

        # Install the APK (Replace with actual APK path)
    & $adbPath -s $deviceIP install -g "C:\AndroidSetup\NTV.apk"
    Start-Sleep -Seconds 5

    # Set Sleep Timer to Never
    & $adbPath -s $deviceIP shell settings put system screen_off_timeout 2147483647
    Start-Sleep -Seconds 1


    Write-Host "Setup complete for $newDeviceName!"
}

Write-Host "All devices configured!"
